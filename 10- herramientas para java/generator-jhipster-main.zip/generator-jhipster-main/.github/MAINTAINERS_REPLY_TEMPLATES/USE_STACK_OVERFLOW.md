This is not a **bug** or **feature request** and hence this is not the correct forum for this.
**If you have a question** please use Stack Overflow, and tag the question with [jhipster](http://stackoverflow.com/questions/tagged/jhipster). This will help the project to keep a clean issue tracker. Also, Stack Overflow will give your question a larger audience:

- This will increase your chances to get an answer
- Answers will be of higher quality, as there is a voting system
- This will also help other users who might have the same issue, as questions are tagged and easily searchable

Finally, you can also use [our chat room on gitter](https://gitter.im/jhipster/generator-jhipster).
