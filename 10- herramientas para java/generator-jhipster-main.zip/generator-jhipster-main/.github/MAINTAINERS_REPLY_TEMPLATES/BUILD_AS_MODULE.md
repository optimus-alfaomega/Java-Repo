This feature is more suitable to be built as a [JHipster module](https://jhipster.tech/modules/marketplace/#/list) so that it can be evaluated first.
If the module ends up being very popular we could consider integrating it into the main project here.

Please refer the documentation on [how to build modules](https://jhipster.tech/modules/creating-a-module/) and look at some of the [existing modules](https://jhipster.tech/modules/marketplace/#/list) for inspiration.
Reach out to us if you need any help like clarification on how the module system works, adding/exposing new methods for the API etc.
You can use the [JHipster module generator](https://github.com/jhipster/generator-jhipster-module) to scaffold a module.
