---
name: 🚀 Feature Request
about: Suggest an improvement.
---

##### **Overview of the feature request**

<!-- Explain the feature request -->

##### **Motivation for or Use Case**

<!-- Explain why this new feature is important for you -->

##### **Related issues or PR**

<!-- Has a similar feature request been asked for before? Please search both closed & open issues -->

- [ ] Checking this box is mandatory (this is just to show you read everything)

<!-- Love JHipster? Please consider supporting our collective:
👉  https://opencollective.com/generator-jhipster/donate -->
