---
name: 🤝 Sponsor the project
about: If you would like to support our efforts in maintaining this community-driven project!
---

--------------^ Click "Preview" for a nicer view!

Support this project by becoming a sponsor! [Become a sponsor](https://opencollective.com/generator-jhipster) or [learn more about sponsoring the project](https://www.jhipster.tech/sponsors/).
